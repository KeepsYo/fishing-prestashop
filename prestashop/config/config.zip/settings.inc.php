<?php
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'prestashop');
define('_DB_USER_', 'prestashop');
define('_DB_PASSWD_', 'prestashop');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', 'yJjistQmd2O7u9H1yO0HoqiwLu2JB7knHDJ8os5B9zW5rxbpaoqNSngq');
define('_COOKIE_IV_', 'cM4c9wCq');
define('_PS_CREATION_DATE_', '2015-11-06');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.1.2');
define('_RIJNDAEL_KEY_', 'LgeqQpWQWiImCxURTA8P1rZUiYQSC4OD');
define('_RIJNDAEL_IV_', '2gjHxtfm10uNq/PYgfxj1w==');
